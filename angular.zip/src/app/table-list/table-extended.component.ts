import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-extended-list',
  templateUrl: './table-extended.component.html',
  styleUrls: ['./table-extended.component.css']
})
export class ExtendedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
