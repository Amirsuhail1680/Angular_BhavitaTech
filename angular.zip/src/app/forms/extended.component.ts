import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-extended',
  templateUrl: './extended.component.html',
  styleUrls: ['./extended.component.css']
})
export class ExtendedsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
