import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-swal',
  templateUrl: './swal.component.html',
  styleUrls: ['./swal.component.css']
})
export class SwalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
